/* 
 * File:   functions.h
 * Author: abdom
 *
 * Created on October 5, 2023, 12:02 PM
 */

#ifndef FUNCTIONS_H
#define	FUNCTIONS_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* FUNCTIONS_H */

