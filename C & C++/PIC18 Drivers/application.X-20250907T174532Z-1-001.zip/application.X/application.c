/* 
 * File:   application.c
 * Author: abdom
 *
 * Created on October 5, 2023, 10:51 AM
 */


#include <stdio.h>
#include <stdlib.h>
#include "application.h"
#include "ECU_Layer/Button/ecu_button.h"
#include "ECU_Layer/Relay/ecu_Relay.h"
#include "ECU_Layer/DC_Motor/ecu_dc_motor.h"
#include "ECU_Layer/Chr_LCD/ecu_chr_LCD.h"
#include <xc.h>
#define _XTAL_FREQ   4000000


/*
 * 
 */

chr_lcd_4bit_t LCD1 = 
{
    .lcd_rs.Port = PORTC_INDEX,
    .lcd_rs.Pin = PIN0,
    .lcd_rs.Logic = LOW,
    .lcd_rs.Direction = OUTPUT,
    
    .lcd_en.Port = PORTC_INDEX,
    .lcd_en.Pin = PIN1,
    .lcd_en.Logic = LOW,
    .lcd_en.Direction = OUTPUT,
    
    .lcd_data[0].Port = PORTC_INDEX,
    .lcd_data[0].Pin = PIN2,
    .lcd_data[0].Logic = LOW,
    .lcd_data[0].Direction = OUTPUT,
    
    .lcd_data[1].Port = PORTC_INDEX,
    .lcd_data[1].Pin = PIN3,
    .lcd_data[1].Logic = LOW,
    .lcd_data[1].Direction = OUTPUT,
    
    .lcd_data[2].Port = PORTC_INDEX,
    .lcd_data[2].Pin = PIN4,
    .lcd_data[2].Logic = LOW,
    .lcd_data[2].Direction = OUTPUT,
    
    .lcd_data[3].Port = PORTC_INDEX,
    .lcd_data[3].Pin = PIN5,
    .lcd_data[3].Logic = LOW,
    .lcd_data[3].Direction = OUTPUT
};


chr_lcd_8bit_t LCD2 = 
{
    .lcd_rs.Port = PORTC_INDEX,
    .lcd_rs.Pin = PIN6,
    .lcd_rs.Logic = LOW,
    .lcd_rs.Direction = OUTPUT,
    
    .lcd_en.Port = PORTC_INDEX,
    .lcd_en.Pin = PIN7,
    .lcd_en.Logic = LOW,
    .lcd_en.Direction = OUTPUT,
    
    .lcd_data[0].Port = PORTD_INDEX,
    .lcd_data[0].Pin = PIN0,
    .lcd_data[0].Logic = LOW,
    .lcd_data[0].Direction = OUTPUT,
    
    .lcd_data[1].Port = PORTD_INDEX,
    .lcd_data[1].Pin = PIN1,
    .lcd_data[1].Logic = LOW,
    .lcd_data[1].Direction = OUTPUT,
    
    .lcd_data[2].Port = PORTD_INDEX,
    .lcd_data[2].Pin = PIN2,
    .lcd_data[2].Logic = LOW,
    .lcd_data[2].Direction = OUTPUT,
    
    .lcd_data[3].Port = PORTD_INDEX,
    .lcd_data[3].Pin = PIN3,
    .lcd_data[3].Logic = LOW,
    .lcd_data[3].Direction = OUTPUT,
    
    .lcd_data[4].Port = PORTD_INDEX,
    .lcd_data[4].Pin = PIN4,
    .lcd_data[4].Logic = LOW,
    .lcd_data[4].Direction = OUTPUT,
    
    .lcd_data[5].Port = PORTD_INDEX,
    .lcd_data[5].Pin = PIN5,
    .lcd_data[5].Logic = LOW,
    .lcd_data[5].Direction = OUTPUT,
    
    .lcd_data[6].Port = PORTD_INDEX,
    .lcd_data[6].Pin = PIN6,
    .lcd_data[6].Logic = LOW,
    .lcd_data[6].Direction = OUTPUT,
    
    .lcd_data[7].Port = PORTD_INDEX,
    .lcd_data[7].Pin = PIN7,
    .lcd_data[7].Logic = LOW,
    .lcd_data[7].Direction = OUTPUT
};

Std_ReturnType ret;

int main() {
    ret = LCD_4bit_Initialize(&LCD1);
    ret = LCD_8bit_Initialize(&LCD2);
    
    while(1)
    {
    
    }
      
        
        
        
    
    
    
    return (EXIT_SUCCESS);
}

