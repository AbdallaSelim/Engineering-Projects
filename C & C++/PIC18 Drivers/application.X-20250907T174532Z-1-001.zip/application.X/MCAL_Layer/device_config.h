/* 
 * File:   device_config.h
 * Author: abdom
 *
 * Created on October 5, 2023, 11:39 AM
 */

#ifndef DEVICE_CONFIG_H
#define	DEVICE_CONFIG_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* DEVICE_CONFIG_H */

