/* 
 * File:   ecu_Relay_cfg.h
 * Author: abdom
 *
 * Created on October 23, 2023, 9:53 AM
 */

#ifndef ECU_RELAY_CFG_H
#define	ECU_RELAY_CFG_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* ECU_RELAY_CFG_H */

