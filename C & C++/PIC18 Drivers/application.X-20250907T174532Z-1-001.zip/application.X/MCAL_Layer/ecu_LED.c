#include "../ECU_Layer/LED/ecu_LED.h"

Std_ReturnType ret;

Std_ReturnType LED_Initialize(const LED_t* LED)
{
    if(NULL == LED)
    {
        ret = E_NOK;
    }
    else
    {
        pin_config_t Pin = {.Port = LED->Port, .Pin = LED->Pin , .Direction = OUTPUT, .Logic = LED->LED_Status}; /* Any LED should be OUTPUT */
        gpio_pin_initialize(&Pin); /* Initialized both direction and logic */
    }
    return ret;
}

Std_ReturnType LED_Turn_ON(const LED_t* LED)
{
    if(NULL == LED)
    {
        ret = E_NOK;
    }
    else
    {
        pin_config_t Pin = {.Port = LED->Port, .Pin = LED->Pin , .Direction = OUTPUT, .Logic = LED->LED_Status}; /* Any LED should be OUTPUT */
        gpio_pin_write_logic(&Pin, HIGH); 
    }
    return ret;
}

Std_ReturnType LED_Turn_OFF(const LED_t* LED)
{
    if(NULL == LED)
    {
        ret = E_NOK;
    }
    else
    {
        pin_config_t Pin = {.Port = LED->Port, .Pin = LED->Pin , .Direction = OUTPUT, .Logic = LED->LED_Status}; /* Any LED should be OUTPUT */
        gpio_pin_write_logic(&Pin, LOW); 
    }
    return ret;
}

Std_ReturnType LED_Turn_Toggle(const LED_t* LED)
{
    if(NULL == LED)
    {
        ret = E_NOK;
    }
    else
    {
        pin_config_t Pin = {.Port = LED->Port, .Pin = LED->Pin , .Direction = OUTPUT, .Logic = LED->LED_Status}; /* Any LED should be OUTPUT */
        gpio_pin_toggle_logic(&Pin); 
    }
    return ret;
}
