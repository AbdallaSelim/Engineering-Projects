/* 
 * File:   hal_gpio.c
 * Author: abdom
 *
 * Created on October 5, 2023, 10:51 AM
 */

#include "hal_gpio.h"

volatile uint8* TRIS[] = {&TRISA, &TRISB, &TRISC, &TRISD, &TRISE};
volatile uint8* PORT[] = {&PORTA, &PORTB, &PORTC, &PORTD, &PORTE};
volatile uint8* LAT[] =  {&LATA, &LATB, &LATC, &LATD, &LATE};

Std_ReturnType gpio_pin_direction_initialize(const pin_config_t* _pin_config)
{
    Std_ReturnType ret = E_OK;
    if(NULL == _pin_config || _pin_config->Pin > PIN_MAX_SIZE - 1)
    {
         ret = E_NOK;
    }
    else
    {
        switch(_pin_config->Direction)
        {
            case OUTPUT:
                RESET_BIT(*TRIS[_pin_config->Port], _pin_config->Pin);
                break;

            case INPUT:
                SET_BIT(*TRIS[_pin_config->Port], _pin_config->Pin);
                break;
            default: ret = E_NOK; /* If neither cases is done, it means there's a problem */
        }
       
    }
    
    
    return ret;
}

Std_ReturnType gpio_pin_write_logic(const pin_config_t* _pin_config, logic_t Logic)
{
    Std_ReturnType ret = E_OK;
    if(NULL == _pin_config )
    {
         ret = E_NOK;
    }
    else
    {
        switch(Logic)
        {
            case HIGH:
                SET_BIT(*LAT[_pin_config->Port], _pin_config->Pin);
                break;

            case LOW:
                RESET_BIT(*LAT[_pin_config->Port],  _pin_config->Pin);
                break;
            default: ret = E_NOK; /* If neither cases is done, it means there's a problem */
        }
    }
    return ret;
}

Std_ReturnType gpio_pin_get_direction_status(const pin_config_t* _pin_config, direction_t* Direction_Status)
{
    Std_ReturnType ret = E_OK;
    if(NULL == _pin_config || NULL == Direction_Status)
    {
         ret = E_NOK;
    }
    else
    {
        *Direction_Status = READ_BIT(*TRIS[_pin_config->Port], _pin_config->Pin);
    }
    return ret;
}
Std_ReturnType gpio_pin_read_logic(const pin_config_t* _pin_config, logic_t* Logic)
{
    Std_ReturnType ret = E_OK;
    if(NULL == _pin_config || NULL == Logic)
    {
         ret = E_NOK;
    }
    else
    {
        *Logic = READ_BIT(*PORT[_pin_config->Port], _pin_config->Pin);
    }
    return ret;
}
Std_ReturnType gpio_pin_toggle_logic(const pin_config_t* _pin_config)
{
    Std_ReturnType ret = E_OK;
    if(NULL == _pin_config)
    {
        ret = E_NOK;
    }
    else
    {
        TOGGLE_BIT(*LAT[_pin_config->Port], _pin_config->Pin);
    }    
    return ret;
}

Std_ReturnType gpio_pin_initialize(const pin_config_t* _pin_config)
{
    Std_ReturnType ret = E_OK;
    if(NULL == _pin_config)
    {
        ret = E_NOK;
    }
    else
    {
        ret = gpio_pin_direction_initialize(_pin_config);
        ret = gpio_pin_write_logic(_pin_config, _pin_config->Logic);
    }
    
    
    return ret;
}

Std_ReturnType gpio_port_direction_initialize(port_index_t port, uint8 Direction)
{
    Std_ReturnType ret = E_OK;
    if(port < PORT_MAX_SIZE)
    {
        *TRIS[port] = Direction; /* Writes in the whole register indexed port */
    }
    else
    {
        ret = E_NOK;
    }
  
    return ret;
}
Std_ReturnType gpio_port_get_direction_status(port_index_t port, uint8* Direction_Status)
{
    Std_ReturnType ret = E_OK;
    if(NULL == Direction_Status || port >= PORT_MAX_SIZE)
    {
         ret = E_NOK;
    }
    else
    {
        *Direction_Status = *TRIS[port];
    }
    return ret;
}
Std_ReturnType gpio_port_write_logic(port_index_t port, uint8 Logic)
{
    Std_ReturnType ret = E_OK;
    if(port >= PORT_MAX_SIZE)
    {
        ret = E_NOK;
    }
    else
    {
        *LAT[port] = Logic;
    }

    return ret;
}
Std_ReturnType gpio_port_read_logic(port_index_t port, uint8* Logic)
{
    Std_ReturnType ret = E_OK;
    if(NULL == Logic)
    {
         ret = E_NOK;
    }
    else
    {
        *Logic = *LAT[port];
    }
    return ret;
}
Std_ReturnType gpio_port_toggle_logic(port_index_t port)
{
    Std_ReturnType ret = E_OK;
    if(port >= PORT_MAX_SIZE)
    {
        ret = E_NOK;
    }
    else
    {
        (*LAT[port]) ^= 0xFF;
    }
 
    return ret;
}