/* 
 * File:   Compiler.h
 * Author: abdom
 *
 * Created on October 5, 2023, 11:26 AM
 */

#ifndef COMPILER_H
#define	COMPILER_H



#endif	/* COMPILER_H */

