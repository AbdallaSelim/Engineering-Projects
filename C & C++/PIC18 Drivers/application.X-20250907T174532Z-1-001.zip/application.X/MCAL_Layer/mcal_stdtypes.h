/* 
 * File:   mcal_stdtypes.h
 * Author: abdom
 *
 * Created on October 5, 2023, 11:21 AM
 */

#ifndef MCAL_STDTYPES_H
#define	MCAL_STDTYPES_H

#include "std_libraries.h"
#include "Compiler.h"

/* Section : Macros Definition */
#define STD_LOW  0x00
#define STD_HIGH 0x01

#define STD_ON  0x01
#define STD_OFF 0x00

#define STD_ACTIVE  0x01
#define STD_IDLE    0x00

#define PIN_MAX_SIZE 8
#define PORT_MAX_SIZE 5

/* Section: Data types declaration */
typedef unsigned char  uint8;
typedef unsigned short uint16;
typedef unsigned long  uint32;
typedef signed char    sint8;
typedef signed short   sint16;
typedef signed long    sint32;

typedef uint8 Std_ReturnType ;

#define E_OK  (Std_ReturnType)0x01
#define E_NOK (Std_ReturnType)0x00


#endif	/* MCAL_STDTYPES_H */

