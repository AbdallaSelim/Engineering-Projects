/* 
 * File:   hal_gpio.h
 * Author: abdom
 *
 * Created on October 5, 2023, 11:19 AM
 */


#ifndef HAL_GPIO_H
#define	HAL_GPIO_H

/* Section : Includes */
#include<xc.h>
#include "mcal_stdtypes.h"
#include "device_config.h"

/* Section : MACROS */

/* Section : MACRO FUNCTIONS */
#define BIT_MASK 1
#define HWREG8(_X) (*((volatile uint8*)(_X)))
#define SET_BIT(REG, BIT) (REG |= (1 << BIT))
#define RESET_BIT(REG, BIT) (REG &= ~(1 << BIT))
#define TOGGLE_BIT(REG, BIT) (REG ^= (1 << BIT))
#define READ_BIT(REG, BIT)  ((REG >> BIT) & 0x01) 

/* Section : Data types */
typedef enum
{
    LOW,
    HIGH
}logic_t;

typedef enum
{
    OUTPUT,
    INPUT
}direction_t;

typedef enum
{
    PIN0,
    PIN1,
    PIN2,
    PIN3,
    PIN4,
    PIN5,
    PIN6,
    PIN7,
}pin_index_t;

typedef enum
{
    PORTA_INDEX,
    PORTB_INDEX,
    PORTC_INDEX,
    PORTD_INDEX,
    PORTE_INDEX,
}port_index_t;

typedef struct
{
    uint8 Port : 3;
    uint8 Pin  : 3;
    uint8 Direction : 1;
    uint8 Logic : 1;
}pin_config_t;

/* Section : Functions Definitions */
Std_ReturnType gpio_pin_direction_initialize(const pin_config_t* _pin_config); 
Std_ReturnType gpio_pin_get_direction_status(const pin_config_t* _pin_config, direction_t* Direction_Status); 
Std_ReturnType gpio_pin_write_logic(const pin_config_t* _pin_config, logic_t Logic); 
Std_ReturnType gpio_pin_read_logic(const pin_config_t* _pin_config, logic_t* Logic);
Std_ReturnType gpio_pin_toggle_logic(const pin_config_t* _pin_config);
Std_ReturnType gpio_pin_initialize(const pin_config_t* _pin_config); 

Std_ReturnType gpio_port_direction_initialize(port_index_t port, uint8 Direction); 
Std_ReturnType gpio_port_get_direction_status(port_index_t port, uint8* Direction_Status); 
Std_ReturnType gpio_port_write_logic(port_index_t port, uint8 Logic); 
Std_ReturnType gpio_port_read_logic(port_index_t port, uint8* Logic);
Std_ReturnType gpio_port_toggle_logic(port_index_t port);
#endif	/* HAL_GPIO_H */

 