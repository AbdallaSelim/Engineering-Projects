/* 
 * File:   application.h
 * Author: abdom
 *
 * Created on October 5, 2023, 11:34 AM
 */

#ifndef APPLICATION_H
#define	APPLICATION_H

#include<xc.h>
#include "../application.X/ECU_Layer/LED/ecu_LED.h"
#include "../application.X/MCAL_Layer/hal_gpio.h"

#endif	/* APPLICATION_H */

