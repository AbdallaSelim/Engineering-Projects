/* 
 * File:   ecu_dc_motor_cfg.h
 * Author: abdom
 *
 * Created on October 23, 2023, 12:37 PM
 */

#ifndef ECU_DC_MOTOR_CFG_H
#define	ECU_DC_MOTOR_CFG_H


#endif	/* ECU_DC_MOTOR_CFG_H */

