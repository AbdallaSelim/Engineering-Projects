/* 
 * File:   ecu_dc_motor.h
 * Author: abdom
 *
 * Created on October 23, 2023, 12:36 PM
 */

#ifndef ECU_DC_MOTOR_H
#define	ECU_DC_MOTOR_H

/* Section : Includes */
#include"ecu_dc_motor_cfg.h"
#include"../../MCAL_Layer/hal_gpio.h"

/* Section: Macros Definition */
#define DC_MOTOR_ON_STATUS 0X01U
#define DC_MOTOR_OFF_STATUS 0X00U


/* Section : Data type declaration */
typedef struct
{
    uint8 Dc_Motor_Port : 4;
    uint8 Dc_Motor_Pin : 3;
    uint8 Dc_Motor_Status : 1;
}Dc_Motor_Pin_t;

typedef struct
{
    Dc_Motor_Pin_t Dc_Motor[2]; /* Each Motor requires 2 pins */
}Dc_Motor_t;

/* Section : Functions Prototypes */
Std_ReturnType Dc_Motor_Initialize(const Dc_Motor_t* Dc_Motor);
Std_ReturnType Dc_Motor_Move_Right(const Dc_Motor_t* Dc_Motor);
Std_ReturnType Dc_Motor_Move_Left(const Dc_Motor_t* Dc_Motor);
Std_ReturnType Dc_Motor_Stop(const Dc_Motor_t* Dc_Motor);


#endif	/* ECU_DC_MOTOR_H */

