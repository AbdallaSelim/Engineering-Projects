#include <stdio.h>

#include"ecu_dc_motor.h"
Std_ReturnType ret;

Std_ReturnType Dc_Motor_Initialize(const Dc_Motor_t* Dc_Motor)
{
    ret = E_OK;
    if(NULL == Dc_Motor)
    {
        ret = E_NOK;
    }
    else
    {
        /* First pin's initialization */
        pin_config_t pin_obj1;
        pin_config_t pin_obj2;

        pin_obj1.Port = Dc_Motor->Dc_Motor[0].Dc_Motor_Port; /* Dc_Motor ptr is a pointer to a struct containing an array of 2 elements */
        pin_obj1.Pin = Dc_Motor->Dc_Motor[0].Dc_Motor_Pin;
        pin_obj1.Logic = Dc_Motor->Dc_Motor[0].Dc_Motor_Status;
        pin_obj1.Direction = OUTPUT;
        
        pin_obj2.Port = Dc_Motor->Dc_Motor[1].Dc_Motor_Port; /* Dc_Motor ptr is a pointer to a struct containing an array of 2 elements */
        pin_obj2.Pin = Dc_Motor->Dc_Motor[1].Dc_Motor_Pin;
        pin_obj2.Logic = Dc_Motor->Dc_Motor[1].Dc_Motor_Status;
        pin_obj2.Direction = OUTPUT;
        
        ret = gpio_pin_initialize(&pin_obj1);
        /* Second pin's initialization */   

        
        
        ret = gpio_pin_initialize(&pin_obj2);
    }
}

Std_ReturnType Dc_Motor_Move_Right(const Dc_Motor_t* Dc_Motor)
{
    ret = E_OK;
    if(NULL == Dc_Motor)
    {
        ret = E_NOK;
    }
    else
    {
        pin_config_t pin_obj1;
        pin_config_t pin_obj2;

        pin_obj1.Port = Dc_Motor->Dc_Motor[0].Dc_Motor_Port; /* Dc_Motor ptr is a pointer to a struct containing an array of 2 elements */
        pin_obj1.Pin = Dc_Motor->Dc_Motor[0].Dc_Motor_Pin;
        pin_obj1.Logic = Dc_Motor->Dc_Motor[0].Dc_Motor_Status;
        pin_obj1.Direction = OUTPUT;
        
        pin_obj2.Port = Dc_Motor->Dc_Motor[1].Dc_Motor_Port; /* Dc_Motor ptr is a pointer to a struct containing an array of 2 elements */
        pin_obj2.Pin = Dc_Motor->Dc_Motor[1].Dc_Motor_Pin;
        pin_obj2.Logic = Dc_Motor->Dc_Motor[1].Dc_Motor_Status;
        pin_obj2.Direction = OUTPUT;
        
        ret = gpio_pin_write_logic(&pin_obj1, HIGH);
        ret = gpio_pin_write_logic(&pin_obj2, LOW);
        
    }
}

Std_ReturnType Dc_Motor_Move_Left(const Dc_Motor_t* Dc_Motor)
{
    ret = E_OK;
    if(NULL == Dc_Motor)
    {
        ret = E_NOK;
    }
    else
    {
        pin_config_t pin_obj1;
        pin_config_t pin_obj2;

        pin_obj1.Port = Dc_Motor->Dc_Motor[0].Dc_Motor_Port; /* Dc_Motor ptr is a pointer to a struct containing an array of 2 elements */
        pin_obj1.Pin = Dc_Motor->Dc_Motor[0].Dc_Motor_Pin;
        pin_obj1.Logic = Dc_Motor->Dc_Motor[0].Dc_Motor_Status;
        pin_obj1.Direction = OUTPUT;
        
        pin_obj2.Port = Dc_Motor->Dc_Motor[1].Dc_Motor_Port; /* Dc_Motor ptr is a pointer to a struct containing an array of 2 elements */
        pin_obj2.Pin = Dc_Motor->Dc_Motor[1].Dc_Motor_Pin;
        pin_obj2.Logic = Dc_Motor->Dc_Motor[1].Dc_Motor_Status;
        pin_obj2.Direction = OUTPUT;
        
        ret = gpio_pin_write_logic(&pin_obj1, LOW);
        ret = gpio_pin_write_logic(&pin_obj2, HIGH);
        
    }
}
Std_ReturnType Dc_Motor_Stop(const Dc_Motor_t* Dc_Motor)
{
    ret = E_OK;
    if(NULL == Dc_Motor)
    {
        ret = E_NOK;
    }
    else
    {
        pin_config_t pin_obj1;
        pin_config_t pin_obj2;

        pin_obj1.Port = Dc_Motor->Dc_Motor[0].Dc_Motor_Port; /* Dc_Motor ptr is a pointer to a struct containing an array of 2 elements */
        pin_obj1.Pin = Dc_Motor->Dc_Motor[0].Dc_Motor_Pin;
        pin_obj1.Logic = Dc_Motor->Dc_Motor[0].Dc_Motor_Status;
        pin_obj1.Direction = OUTPUT;
        
        pin_obj2.Port = Dc_Motor->Dc_Motor[1].Dc_Motor_Port; /* Dc_Motor ptr is a pointer to a struct containing an array of 2 elements */
        pin_obj2.Pin = Dc_Motor->Dc_Motor[1].Dc_Motor_Pin;
        pin_obj2.Logic = Dc_Motor->Dc_Motor[1].Dc_Motor_Status;
        pin_obj2.Direction = OUTPUT;
        
        ret = gpio_pin_write_logic(&pin_obj1, LOW);
        ret = gpio_pin_write_logic(&pin_obj2, LOW);
        
    }
}

