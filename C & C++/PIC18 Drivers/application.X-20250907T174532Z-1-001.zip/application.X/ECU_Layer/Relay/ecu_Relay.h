/* 
 * File:   ecu_Relay.h
 * Author: abdom
 *
 * Created on October 23, 2023, 9:52 AM
 */

#ifndef ECU_RELAY_H
#define	ECU_RELAY_H

/* section: Includes */
#include"../ecu_Relay_cfg.h"
#include"../../MCAL_Layer/hal_gpio.h"

/* Section : Macros Definition */
#define RELAY_ON 0X01U
#define RELAY_OFF 0X00U

/* Section : Data type Declaration */
typedef struct
{
    uint8 Relay_Port : 4;
    uint8 Relay_Pin : 3;
    uint8 Relay_Status : 1;
}Relay_t;

/* Section : Functions Prototypes */
Std_ReturnType Relay_Initialize(const Relay_t* Relay);
Std_ReturnType Relay_Turn_ON(const Relay_t* Relay);
Std_ReturnType Relay_Turn_OFF(const Relay_t* Relay);

#endif	/* ECU_RELAY_H */

