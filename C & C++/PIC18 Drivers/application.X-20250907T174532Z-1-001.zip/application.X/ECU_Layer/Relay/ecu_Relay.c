#include"ecu_Relay.h"
Std_ReturnType ret;
Std_ReturnType Relay_Initialize(const Relay_t* Relay)
{
    ret = E_OK;
    if(NULL == Relay)
    {
        ret = E_NOK;
    }
    else
    {
        pin_config_t pin_obj = {.Port = Relay->Relay_Port, .Pin = Relay->Relay_Pin, .Logic = Relay->Relay_Status, .Direction = OUTPUT};
        gpio_pin_initialize(&pin_obj);
    }
}

Std_ReturnType Relay_Turn_ON(const Relay_t* Relay)
{
    ret = E_OK;
    if(NULL == Relay)
    {
        ret = E_NOK;
    }
    else
    {
        pin_config_t pin_obj = {.Port = Relay->Relay_Port, .Pin = Relay->Relay_Pin, .Logic = Relay->Relay_Status, .Direction = OUTPUT};
        gpio_pin_write_logic(&pin_obj, HIGH);
    }
}

Std_ReturnType Relay_Turn_OFF(const Relay_t* Relay)
{
    ret = E_OK;
    if(NULL == Relay)
    {
        ret = E_NOK;
    }
    else
    {
        pin_config_t pin_obj = {.Port = Relay->Relay_Port, .Pin = Relay->Relay_Pin, .Logic = Relay->Relay_Status, .Direction = OUTPUT};
        gpio_pin_write_logic(&pin_obj, LOW);
    }
}
