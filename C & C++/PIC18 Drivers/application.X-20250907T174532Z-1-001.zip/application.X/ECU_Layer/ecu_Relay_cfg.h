/* 
 * File:   ecu_Relay_cfg.h
 * Author: abdom
 *
 * Created on October 23, 2023, 9:54 AM
 */

#ifndef ECU_RELAY_CFG_H
#define	ECU_RELAY_CFG_H


#endif	/* ECU_RELAY_CFG_H */

