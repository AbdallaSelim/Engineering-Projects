/* 
 * File:   ecu_chr_LCD_cfg.h
 * Author: abdom
 *
 * Created on November 5, 2023, 1:52 PM
 */

#ifndef ECU_CHR_LCD_CFG_H
#define	ECU_CHR_LCD_CFG_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* ECU_CHR_LCD_CFG_H */

