#include"ecu_chr_LCD.h"
#include<string.h>
#include<stdlib.h>
#define _XTAL_FREQ   4000000


static Std_ReturnType lcd_send_4bits(const chr_lcd_4bit_t* lcd, uint8 data);
static Std_ReturnType lcd_4bits_Send_Enable(const chr_lcd_4bit_t* lcd);
static Std_ReturnType lcd_8bit_set_cursor(const chr_lcd_8bit_t* lcd, uint8 row, uint8 column);

Std_ReturnType LCD_4bit_Initialize(const chr_lcd_4bit_t* lcd)
{
    Std_ReturnType ret = E_OK;
    uint8 Counter = 0;
    if(NULL == lcd)
    {
        ret = E_NOK;
    }
    else
    {
        ret = gpio_pin_initialize(&(lcd->lcd_rs));
        ret = gpio_pin_initialize(&(lcd->lcd_en));
        for(Counter = 0 ; Counter < 4; Counter++)
        {
            ret = gpio_pin_initialize(&(lcd->lcd_data[Counter]));
        }
    }
}


Std_ReturnType LCD_4bit_Send_Command(const chr_lcd_4bit_t* lcd, uint8 Command)
{
    Std_ReturnType ret = E_OK;
    if(NULL == lcd)
    {
        ret = E_NOK;
    }
    else
    {
        ret = gpio_pin_write_logic(&(lcd->lcd_rs), LOW); /* To send COMMAND, select Instruction Register (RS = 0) */
        ret  = lcd_send_4bits(lcd, (Command >> 4));   
        ret = lcd_4bits_Send_Enable(lcd);
        ret  = lcd_send_4bits(lcd, (Command)); 
        ret = lcd_4bits_Send_Enable(lcd); 
    }
    return ret;
}


Std_ReturnType LCD_4bit_Send_Char_Data(const chr_lcd_4bit_t* lcd, uint8 Data)
{
    Std_ReturnType ret = E_OK;
    if(NULL == lcd)
    {
        ret = E_NOK;
    }
    else
    {
        ret = gpio_pin_write_logic(&(lcd->lcd_rs), HIGH); /* To write data, select Data Register (RS = 1) */
        ret  = lcd_send_4bits(lcd, (Data >> 4));   
        ret = lcd_4bits_Send_Enable(lcd);
        ret  = lcd_send_4bits(lcd, (Data)); 
        ret = lcd_4bits_Send_Enable(lcd); 
    }
    return ret;
}


Std_ReturnType LCD_4bit_Send_Char_Data_pos(const chr_lcd_4bit_t* lcd, uint8 Row, uint8 Column, uint8 Data )
{
    Std_ReturnType ret = E_OK;
    if(NULL == lcd)
    {
        ret = E_NOK;
    }
    else
    {
       
    }
    return ret;
}


Std_ReturnType LCD_4bit_Send_String(const chr_lcd_4bit_t* lcd, uint8* String)
{
    
}


Std_ReturnType LCD_4bit_Send_String_pos(const chr_lcd_4bit_t* lcd, uint8 Row, uint8 Column, uint8* String)
{
    
}


Std_ReturnType LCD_4bit_Send_Custom_Char(const chr_lcd_4bit_t* lcd, uint8 Row, uint8 Column, const uint8 _Char[], uint8 mem_pos)
{
    
}

/* 8 Bit section */
Std_ReturnType LCD_8bit_Initialize(const chr_lcd_8bit_t* lcd)
{
    Std_ReturnType ret = E_OK;
    uint8 Counter = 0;
    if(NULL == lcd)
    {
        ret = E_NOK;
    }
    else
    {
        ret = gpio_pin_initialize(&(lcd->lcd_rs));
        ret = gpio_pin_initialize(&(lcd->lcd_en));
        for(Counter = 0 ; Counter < 8; Counter++)
        {
            ret = gpio_pin_initialize(&(lcd->lcd_data[Counter]));
        }
        __delay_ms(20);
        ret = LCD_8bit_Send_Command(lcd, LCD_8BIT_MODE2_LINE);
        __delay_ms(5);
        ret = LCD_8bit_Send_Command(lcd, LCD_8BIT_MODE2_LINE);
        __delay_us(150);
        ret = LCD_8bit_Send_Command(lcd, LCD_8BIT_MODE2_LINE);
        ret = LCD_8bit_Send_Command(lcd, LCD_CLEAR);
        ret = LCD_8bit_Send_Command(lcd, LCD_RETURN_HOME);
        ret = LCD_8bit_Send_Command(lcd, LCD_ENTRY_MODE);
        ret = LCD_8bit_Send_Command(lcd, LCD_CURSOR_OFF_DISPLAY_ON);
        ret = LCD_8bit_Send_Command(lcd, LCD_8BIT_MODE2_LINE);
        ret = LCD_8bit_Send_Command(lcd, 0X80);
        
    }
}


Std_ReturnType LCD_8bit_Send_Command(const chr_lcd_8bit_t* lcd, uint8 Command)
{
    Std_ReturnType ret = E_OK;
    if(NULL == lcd)
    {
        ret = E_NOK;
    }
    else
    {
        ret = gpio_pin_write_logic(&(lcd->lcd_rs), LOW); /* To send COMMAND, select Instruction Register (RS = 0) */
        for(uint8 Counter = 0 ; Counter < 8; Counter++)
        {
            ret = gpio_pin_write_logic(&(lcd->lcd_data[Counter]), (Command >> Counter) & (uint8) 0x01);
        }
    }
    return ret;
}

Std_ReturnType LCD_8bit_Send_Char_Data(const chr_lcd_8bit_t* lcd, uint8 Data);
Std_ReturnType LCD_8bit_Send_Char_Data_pos(const chr_lcd_8bit_t* lcd, uint8 Row, uint8 Column, uint8 Data )
{
    Std_ReturnType ret = E_OK;
    if(NULL == lcd)
    {
        ret = E_NOK;
    }
    else
    {
        ret = lcd_8bit_set_cursor(lcd, Row, Column);
    }
    return ret;
}


Std_ReturnType LCD_8bit_Send_String(const chr_lcd_8bit_t* lcd, uint8* String);
Std_ReturnType LCD_8bit_Send_String_pos(const chr_lcd_8bit_t* lcd, uint8 Row, uint8 Column, uint8* String);
Std_ReturnType LCD_8bit_Send_Custom_Char(const chr_lcd_8bit_t* lcd, uint8 Row, uint8 Column, const uint8 _Char[], uint8 mem_pos);


Std_ReturnType Convert_Byte_to_String(uint8 value, uint8* str)
{
    Std_ReturnType ret = E_OK;
    if(NULL == str)
    {
        ret = E_NOK;
    }
    else
    {
        memset(str, '\0' , 4);
        sprintf(str, "%i", value);
    }
    
    return ret;
}


Std_ReturnType Convert_Short_to_String(uint16 value, uint8* str)
{
    Std_ReturnType ret = E_OK;
    if(NULL == str)
    {
        ret = E_NOK;
    }
    else
    {
        memset(str, '\0' , 6);
        sprintf(str, "%i", value);
    }
    
    return ret;
}


Std_ReturnType Convert_Int_to_String(uint32 value, uint8* str)
{
    Std_ReturnType ret = E_OK;
    if(NULL == str)
    {
        ret = E_NOK;
    }
    else
    {
        memset(str, '\0' , 11);
        sprintf(str, "%i", value);
    }
    
    return ret;
}



static Std_ReturnType lcd_send_4bits(const chr_lcd_4bit_t* lcd, uint8 data)
{
    Std_ReturnType ret = E_OK;
    uint8 Counter = 0;
    if(NULL == lcd)
    {
        ret = E_NOK;
    }
    else
    {
        for(Counter = 0; Counter < 4; Counter++)
        {
            ret = gpio_pin_write_logic(&(lcd->lcd_data[Counter]), (data >> Counter) & (uint8)0x01);
        } 
    }
    
    return ret;
    
}

static Std_ReturnType lcd_4bits_Send_Enable(const chr_lcd_4bit_t* lcd)
{
    Std_ReturnType ret = E_OK;
    if(NULL == lcd)
    {
        ret = E_NOK;
    }
    else
    {
        ret = gpio_pin_write_logic(lcd, HIGH);
        __delay_us(5);
        ret = gpio_pin_write_logic(lcd, LOW);
    }
    
    return ret;
}

static Std_ReturnType lcd_8bit_set_cursor(const chr_lcd_8bit_t* lcd, uint8 row, uint8 column)
{
    Std_ReturnType ret = E_OK;
    if(NULL == lcd)
    {
        ret = E_NOK;
    }
    else
    {
        switch(row)
        {
            case 0: ret = LCD_8bit_Send_Command(lcd, (0x80 + column)); break;
            case 1: ret = LCD_8bit_Send_Command(lcd, (0xC0 + column)); break;
            case 2: ret = LCD_8bit_Send_Command(lcd, (0x94 + column)); break;
            case 3: ret = LCD_8bit_Send_Command(lcd, (0xd4 + column)); break;
        }
    }
    return ret;
}