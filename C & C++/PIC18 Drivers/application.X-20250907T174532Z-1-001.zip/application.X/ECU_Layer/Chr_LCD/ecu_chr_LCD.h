/* 
 * File:   ecu_chr_LCD.h
 * Author: abdom
 *
 * Created on November 5, 2023, 1:51 PM
 */

#ifndef ECU_CHR_LCD_H
#define	ECU_CHR_LCD_H

#include"ecu_chr_LCD_cfg.h"
#include"../../MCAL_Layer/hal_gpio.h"

/* Section : Macros Definition */
#define LCD_CLEAR 0X01
#define LCD_RETURN_HOME 0X02
#define LCD_ENTRY_MODE 0X06
#define LCD_CURSOR_OFF_DISPLAY_ON 0X0C

#define LCD_8BIT_MODE2_LINE 0X38 

/* Section : Datatype definitions */
typedef struct 
{
    pin_config_t lcd_rs;
    pin_config_t lcd_en;
    pin_config_t lcd_data[4];
}chr_lcd_4bit_t;
typedef struct 
{
    pin_config_t lcd_rs;
    pin_config_t lcd_en;
    pin_config_t lcd_data[8];
}chr_lcd_8bit_t;

/* Section : Function Definition */
Std_ReturnType LCD_4bit_Initialize(const chr_lcd_4bit_t* lcd);
Std_ReturnType LCD_4bit_Send_Command(const chr_lcd_4bit_t* lcd, uint8 Command);
Std_ReturnType LCD_4bit_Send_Char_Data(const chr_lcd_4bit_t* lcd, uint8 Data);
Std_ReturnType LCD_4bit_Send_Char_Data_pos(const chr_lcd_4bit_t* lcd, uint8 Row, uint8 Column, uint8 Data );
Std_ReturnType LCD_4bit_Send_String(const chr_lcd_4bit_t* lcd, uint8* String);
Std_ReturnType LCD_4bit_Send_String_pos(const chr_lcd_4bit_t* lcd, uint8 Row, uint8 Column, uint8* String);
Std_ReturnType LCD_4bit_Send_Custom_Char(const chr_lcd_4bit_t* lcd, uint8 Row, uint8 Column, const uint8 _Char[], uint8 mem_pos);

/* 8 Bit section */
Std_ReturnType LCD_8bit_Initialize(const chr_lcd_8bit_t* lcd);
Std_ReturnType LCD_8bit_Send_Command(const chr_lcd_8bit_t* lcd, uint8 Command);
Std_ReturnType LCD_8bit_Send_Char_Data(const chr_lcd_8bit_t* lcd, uint8 Data);
Std_ReturnType LCD_8bit_Send_Char_Data_pos(const chr_lcd_8bit_t* lcd, uint8 Row, uint8 Column, uint8 Data );
Std_ReturnType LCD_8bit_Send_String(const chr_lcd_8bit_t* lcd, uint8* String);
Std_ReturnType LCD_8bit_Send_String_pos(const chr_lcd_8bit_t* lcd, uint8 Row, uint8 Column, uint8* String);
Std_ReturnType LCD_8bit_Send_Custom_Char(const chr_lcd_8bit_t* lcd, uint8 Row, uint8 Column, const uint8 _Char[], uint8 mem_pos);

Std_ReturnType Convert_Byte_to_String(uint8 value, uint8* str);
Std_ReturnType Convert_Short_to_String(uint16 value, uint8* str);
Std_ReturnType Convert_Int_to_String(uint32 value, uint8* str);

#endif	/* ECU_CHR_LCD_H */

