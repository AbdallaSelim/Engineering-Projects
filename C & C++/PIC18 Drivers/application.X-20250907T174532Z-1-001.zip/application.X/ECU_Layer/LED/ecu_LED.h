/* 
 * File:   ecu_LED.h
 * Author: abdom
 *
 * Created on October 5, 2023, 11:30 AM
 */

#ifndef ECU_LED_H
#define	ECU_LED_H

#include"ecu_LED_cfg.h"
#include"../../MCAL_Layer/hal_gpio.h"

/* Section ; Data type declaration */
typedef enum
{
    LED_OFF,
    LED_ON
}led_status_t;

typedef struct
{
    uint8 Port : 3;
    uint8 Pin : 3;
    uint8 LED_Status : 1;
    uint8 Researved : 1; /* Not in use */
}LED_t;

/* Section : Functions prototypes */
Std_ReturnType LED_Initialize(const LED_t* LED);
Std_ReturnType LED_Turn_ON(const LED_t* LED);
Std_ReturnType LED_Turn_OFF(const LED_t* LED);
Std_ReturnType LED_Turn_Toggle(const LED_t* LED);


#endif	/* ECU_LED_H */

