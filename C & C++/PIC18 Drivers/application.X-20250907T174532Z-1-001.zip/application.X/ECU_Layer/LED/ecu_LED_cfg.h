/* 
 * File:   ecu_LED_cfg.h
 * Author: abdom
 *
 * Created on October 15, 2023, 9:28 AM
 */

#ifndef ECU_LED_CFG_H
#define	ECU_LED_CFG_H


#endif	/* ECU_LED_CFG_H */

