#include"ecu_button.h"
Std_ReturnType ret;
logic_t Button_Logic;

Std_ReturnType Button_Initialize(const Button_t* Button)
{
    ret = E_OK;
    if(NULL == Button)
    {
        ret = E_NOK;
    }
    else
    {   
        ret = gpio_pin_direction_initialize(&(Button->Button_Pin));
    }
    return ret;
}
Std_ReturnType Button_Read_State(const Button_t* Button, Button_State_t* State)
{
    ret = E_OK;
    if(NULL == Button || NULL == State) 
    {
        ret = E_NOK;
    }
    else
    {
        ret = gpio_pin_read_logic(&(Button->Button_Pin), &Button_Logic);
        if(ACTIVE_HIGH == Button->Button_Connection)
        {
            if(HIGH == (Button_Logic))
            {
                *State = PRESSED; /* an active high push button and the pin is HIGH so it's pressed */
            }
            else
            {
                *State = RELEASED;
            }
        }
        else if(ACTIVE_LOW == Button->Button_Connection)
        {
            if(HIGH == (Button_Logic))
            {
                *State = RELEASED; /* an active high push button and the pin is HIGH so it's Released */
            }
            else
            {
                *State = PRESSED;
            }
        }
        else{/* Can't be left empty - Nothing */}
        
    }
    return ret;
}
