/* 
 * File:   ecu_button_cfg.h
 * Author: abdom
 *
 * Created on October 15, 2023, 11:56 AM
 */

#ifndef ECU_BUTTON_CFG_H
#define	ECU_BUTTON_CFG_H



#endif	/* ECU_BUTTON_CFG_H */

