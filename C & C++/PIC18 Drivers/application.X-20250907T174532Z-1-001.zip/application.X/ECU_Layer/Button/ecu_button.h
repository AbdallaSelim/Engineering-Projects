/* 
 * File:   ecu_button.h
 * Author: abdom
 *
 * Created on October 15, 2023, 11:55 AM
 */

#ifndef ECU_BUTTON_H
#define	ECU_BUTTON_H

/* Section : Includes*/
#include"ecu_button_cfg.h"
#include"../../MCAL_Layer/hal_gpio.h"

/* Section : Data types declaration */
typedef enum
{
    PRESSED,
    RELEASED
}Button_State_t;

typedef enum
{
    ACTIVE_HIGH,
    ACTIVE_LOW
}Button_Active_t;

typedef struct
{
    pin_config_t Button_Pin;
    Button_State_t Button_State;
    Button_Active_t Button_Connection;
    
}Button_t;

/* Section : Functions Prototypes */
Std_ReturnType Button_Initialize(const Button_t* Button);
Std_ReturnType Button_Read_State(const Button_t* Button, Button_State_t* State); /* State used to save the button state - 2 variables returned */

#endif	/* ECU_BUTTON_H */

