/* 
 * File:   ECU_Stepper.h
 * Author: abdom
 *
 * Created on November 11, 2023, 11:51 AM
 */

#ifndef ECU_STEPPER_H
#define	ECU_STEPPER_H
/* Section : Includes */
#include"../MCAL_Layer/GPIO/HAL_GPIO.h"


/* Section : Macros Definition */

/* Section : data type Initialization */

/* Section : Function Prototypes */


#endif	/* ECU_STEPPER_H */

