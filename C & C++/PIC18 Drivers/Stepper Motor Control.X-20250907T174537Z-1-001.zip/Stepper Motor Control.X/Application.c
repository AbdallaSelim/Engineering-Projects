/* Section : Includes */
#include"Application.h"

/* Section : Macros Definition */
#define _XTAL_FREQ 20000000
/* Section : data type Initialization */

/* Section : Global variables */
Pin_Initialize Motor1[] = 
{
    {PORTC_Index, PIN0, OUTPUT, LOW},
    {PORTC_Index, PIN1, OUTPUT, LOW},
    {PORTC_Index, PIN6, OUTPUT, LOW},
    {PORTC_Index, PIN7, OUTPUT, LOW},
    
};
Pin_Initialize LED_Pin5 = 
{
    PORTD_Index, PIN0, OUTPUT, LOW
};

uint8 Counter;

int main()
{
    for(Counter = 0; Counter <= 4; Counter++)
    {
        GPIO_Pin_Initialize(&Motor1[Counter]);
    }
    GPIO_Pin_Initialize(&LED_Pin5);
    GPIO_Pin_Write_Logic(&LED_Pin5, HIGH);
    
    while(1)
    {
        /* Full Step Mode */
        
        for(Counter = 0; Counter <= 4; Counter++)
        {
            GPIO_Pin_Write_Logic(&Motor1[Counter], HIGH);
            __delay_ms(25);
            GPIO_Pin_Write_Logic(&Motor1[Counter], LOW);
        }
    



    }
    
}