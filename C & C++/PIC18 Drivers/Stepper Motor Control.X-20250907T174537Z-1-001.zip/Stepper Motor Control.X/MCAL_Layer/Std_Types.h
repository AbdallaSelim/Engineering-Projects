/* 
 * File:   Std_Types.h
 * Author: abdom
 *
 * Created on November 11, 2023, 12:03 PM
 */

#ifndef STD_TYPES_H
#define	STD_TYPES_H
/* Section : Includes */

/* Section : Macros Definition */
#define E_OK 0
#define E_NOK 1

/* Section : data type Initialization */
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned long uint32;
typedef unsigned long long uint64;


/* Section : Function Prototypes */


#endif	/* STD_TYPES_H */

