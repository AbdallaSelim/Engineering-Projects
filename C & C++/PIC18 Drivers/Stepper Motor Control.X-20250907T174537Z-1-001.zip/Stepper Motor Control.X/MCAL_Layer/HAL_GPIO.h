/* 
 * File:   HAL_GPIO.h
 * Author: abdom
 *
 * Created on November 11, 2023, 11:59 AM
 */

#ifndef HAL_GPIO_H
#define	HAL_GPIO_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* HAL_GPIO_H */

