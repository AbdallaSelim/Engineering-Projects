/* 
 * File:   HAL_GPIO.h
 * Author: abdom
 *
 * Created on November 11, 2023, 12:00 PM
 */

#ifndef HAL_GPIO_H
#define	HAL_GPIO_H

/* Section : Includes */
#include<xc.h>
#include"../Std_Types.h"

/* Section : Macros Definition */
#define SET_BIT(num, pos)   ((num) |= (1 << (pos)))

#define RESET_BIT(num, pos) ((num) &= ~(1 << (pos)))

#define TOGGLE_BIT(num, pos) ((num) ^= (1 << (pos)))

#define READ_BIT(num, pos) ((num >> pos) & 0x01) //Resets everything except the bit we want

/* Section : data type Initialization */
typedef enum
{
    LOW, HIGH
}Logic_t;

typedef enum
{
    OUTPUT, INPUT //OUTPUT = 0 , INPUT = 1
}Direction_t;

typedef enum 
{
    PORTA_Index, PORTB_Index, PORTC_Index, PORTD_Index, PORTE_Index //5 ports, 3 main registers (TRIS, LAT, PORT)
}Port_Index_t;

typedef enum
{
    PIN0, PIN1, PIN2, PIN3, PIN4, PIN5, PIN6, PIN7 //8-Bit architecture
}Pin_Index_t;

typedef struct
{
    uint8 Port : 3; // 5 ports, 3 bits minimum
    uint8 Pin : 3;
    uint8 Direction : 1;
    uint8 Logic : 1;         
}Pin_Initialize;

/* Section : Function Prototypes */
uint8 GPIO_Pin_Direction_Initialize(Pin_Initialize* Pin);
uint8 GPIO_Pin_Initialize(Pin_Initialize* Pin);
uint8 GPIO_Pin_Write_Logic(Pin_Initialize* Pin, Logic_t Logic);
uint8 GPIO_Pin_Read_Logic(Pin_Initialize* Pin, Logic_t* Logic);


#endif	/* HAL_GPIO_H */

