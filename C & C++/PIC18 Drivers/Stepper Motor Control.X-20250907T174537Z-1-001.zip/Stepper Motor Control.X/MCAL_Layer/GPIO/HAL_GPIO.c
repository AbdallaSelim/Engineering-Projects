/* Section : Includes */
#include"HAL_GPIO.h"


/* Section : Macros Definition */

/* Section : data type Initialization */

/* Section : Function Prototypes */

/* Section : Global variable initialization */
uint8 ret;

// The following arrays are pointers to a location in the memory. For that reason, we use & before them
volatile uint8* TRIS[] = {&TRISA, &TRISB, &TRISC, &TRISD, &TRISE};
volatile uint8* LAT[] = {&LATA, &LATB, &LATC, &LATD, &LATE};
volatile uint8* PORT[] = {&PORTA, &PORTB, &PORTC, &PORTD, &PORTE};

/* Section : Functions Implementation */
uint8 GPIO_Pin_Direction_Initialize(Pin_Initialize* Pin) // Direction -> change TRIS
{
    if(NULL == Pin || Pin->Port > 5 || Pin->Pin > 7)
    {
        ret = E_NOK;
    }
    else
    {
        switch(Pin->Direction)
        {
            case OUTPUT: RESET_BIT(*TRIS[Pin->Port], Pin->Pin); break;
            case INPUT: SET_BIT(*TRIS[Pin->Port], Pin->Pin); break;
            default: ret = E_NOK;
        }
    }
    return ret;
}

uint8 GPIO_Pin_Write_Logic(Pin_Initialize* Pin, Logic_t Logic) // Write using LAT
{
    if(NULL == Pin)
    {
        ret = E_NOK;
    }
    else
    {
        switch(Logic)
        {
            case LOW: RESET_BIT(*LAT[Pin->Port], Pin->Pin); break; // reset the pin in LAT register 
            case HIGH: SET_BIT(*LAT[Pin->Port], Pin->Pin); break; // set the pin in LAT register 
            default : ret = E_NOK;
        }
    }
    return ret;
}

uint8 GPIO_Pin_Initialize(Pin_Initialize* Pin)
{
    if(NULL == Pin)
    {
        ret = E_NOK;
    }
    else
    {
        GPIO_Pin_Direction_Initialize(Pin);
        GPIO_Pin_Write_Logic(Pin, Pin->Logic);
    }
    return ret;
}

uint8 GPIO_Pin_Read_Logic(Pin_Initialize* Pin, Logic_t* Logic)//Read from LAT in Logic's address
{
    if(NULL == Pin || NULL == Logic)
    {
        ret = E_NOK;
    }
    else
    {
        *Logic = READ_BIT(*LAT[Pin->Port], Pin->Pin);
    }
    return ret;
}

