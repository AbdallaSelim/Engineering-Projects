
/* 
 * File:   application.c
 * Author: abdom
 *
 * Created on October 5, 2023, 10:51 AM
 */

#define AHMED_LATC (*(volatile unsigned char *)(0xF8B))
#define SET_BIT(REG, BIT) (REG |= (1 << BIT))
#define RESET_BIT(REG, BIT) (REG &= ~(1 << BIT))
#define TOGGLE_BIT(REG, BIT) (REG ^= (1 << BIT))

#include <stdio.h>
#include <stdlib.h>
#include<xc.h>
#include"pic18f4620.h"
/*
 * 
 */


typedef union 
{
    struct
    {
        unsigned LATC0 : 1;
        unsigned LATC1 : 1;
        unsigned LATC2 : 1;
        unsigned LATC3 : 1;
        unsigned LATC4 : 1;
        unsigned LATC5 : 1;
        unsigned LATC6 : 1;
        unsigned LATC7 : 1;
    };
    unsigned char LATC_REG;
}SELF_LATC;

#define SELF_LATC_PTR ((volatile SELF_LATC *)(0XF8B))
#define AHMED_TRISC   (*((volatile unsigned char *)0xF94))

int main() 
{
    AHMED_TRISC = 0x00;
    while(1)
    {
        //__delay_ms(2000);
        SELF_LATC_PTR->LATC_REG = 0X55; /* 0101 0101 */
        //__delay_ms(2000);
        SELF_LATC_PTR->LATC1 = 1; /* 0000 0010 */
        //__delay_ms(2000);
    }
    return 0;
}

